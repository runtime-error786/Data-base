#include "Project.h"
#include<list>
#include<iostream>
#include<fstream>
#include<conio.h>
#include<cstring>
#include<string>
#include<Windows.h>
using namespace std;

int admin_choice;
string reguser, regpass;
int choicelog;

bool shopping::Admin_login() {
    system("cls");
    cout << "\t\t\t\tUser name : ";
    cin >> SAName;
    cout << "\t\t\t\tPassword : ";
    while ((ch = _getch()) != 13) {
        cout << "*";
        SAPass[i] = ch;
        i++;
    }
    SAPass[i] = '\0';
    srand(time(0));
    gen_captcha = rand();
    cout << endl << "\t\t\tEnter this number below : " << gen_captcha << endl;
    cout << "\t\t\tEnter the above number : ";
    cin >> Input_captcha;
    if ((strcmp(SAName, "admin") == 0) && (strcmp(SAPass, "admin") == 0) && (Input_captcha == gen_captcha)) {
        cout << endl << "\t\t\t\t | Veryfing Admin | " << endl;
        cout << "\t\t\t\t ";
        for (int s = 1; s < 5; s++) {
            Sleep(500);
            cout << "......";
        }
        cout << endl << endl << "\t\t\t\t   Access Granted... ;)" << endl << endl;
        system("pause");
        system("cls");
        int x = true;
        administrator();
        return true;
    }
    else
    {
        cout << endl << "\t\t\t\t | Veryfing Admin | " << endl;
        cout << "\t\t\t\t ";
        for (int s = 1; s < 5; s++) {
            Sleep(400);
            cout << "......";
        }
        cout << endl << endl << "\t\t\t\t   Access Denied... :(" << endl << endl;
        system("pause");
        menu();
        system("pause");
        return false;
    }
}

void shopping::administrator() {
    system("cls");
    cout << "\n\n\n\t\t\t Administrator Menu\n";
    cout << "\n\t\t   1- Add Teacher Data";
    cout << "\n\t\t   2- Add Student Data";
    cout << "\n\t\t   3- Edit Teacher Data";
    cout << "\n\t\t   4- Edit Stuednt Data";
    cout << "\n\t\t   5- Exit";
    cout << "\n\n\t   Please enter your choice : ";
    cin >> admin_choice;
    while (admin_choice != 5)
    {
        switch (admin_choice)
        {
        case 1:
            add();
            system("pause");
            system("cls");
            administrator();
            break;
        case 2:
            add();
            system("pause");
            system("cls");
            administrator();
            break;
        case 3:
            edit();
            system("pause");
            system("cls");
            administrator();
            break;
        case 4:
            edit();
            system("pause");
            system("cls");
            break;
        case 5:
            exit(0);
        default:
            cout << "Enter Valid Choice : ";
            system("pause");
            administrator();
        }
    }
}

void shopping::menu() {
    system("cls");
    cout << "\t\t\t\t     Student Management System  " << endl;
    cout << "\t\t\t\t         1- Administrator       " << endl;
    cout << "\t\t\t\t         2- Exit                " << endl;
    cout << "\n\t     Please select : ";
    cin >> choicelog;
    switch (choicelog) {
    case 1:
        Admin_login();
        break;
    case 2:
        exit(0);
    default:
        cout << "Please enter from the given options : ";
        system("pause");
        menu();
    }
}

void shopping::add() {
    system("cls");
    //if (admin_choice == 3) {
    //    token--;
    //}
    if (admin_choice == 1 || admin_choice == 3) {
        cout << "ADD TEACHER DETAILS" << endl << endl;
    }
    else if (admin_choice == 2 || admin_choice == 4) {
        cout << "ADD STUDENT DETAILS" << endl << endl;

    }
    ifstream fileread;
    if (admin_choice == 3) {
        fileread.open("teacher.txt");
    }
    else if (admin_choice == 4) {
        fileread.open("student.txt");
    }
    string variable;
    while (!fileread.eof()) {
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        fileread >> variable;
        token++;
        if (fileread.eof()) {
            break;
        }
    }
    //token--;
    fstream file;
    /* cout << "Enter Identification Number: ";
     cin >> cid;*/
    if (this->m == false) {
        this->cid = token;
        this->cid = this->cid + "\0";
    }
    cout << "Enter First Name: ";
    cin >> firstname;
    cout << "Enter Last Name: ";
    cin >> lastname;
    cout << "Enter the username :";
    cin >> reguser;
    cout << "Enter email : ";
    cin >> email;
    cout << "Enter date : ";
    cin >> date;
A:
    cout << "Enter gender : ";
    cin >> gender;
    if (gender != "M" && gender != "F") {
        cout << "Invalid Gender" << endl;
        goto A;
    }
C:
    cout << "Enter blood : ";
    cin >> blood;
    if (blood != "A-" && blood != "A+" && blood != "B-" && blood != "B+" && blood != "O-" && blood != "O+" && blood != "AB-" && blood != "AB+") {
        cout << "Invalid Blood Group" << endl;
        goto C;
    }
B:
    cout << "Enter Your Mobile Number: ";
    cin >> phone_no;
    if (phone_no.length() != 11)
    {
        cout << "Invalid Phone Number";
        goto B;
    }
    else
    {
        // The First letter should not start with 0 or 1
        if (phone_no[0] != '0' || phone_no[0] == '1')
        {
            cout << "Invalid Phone Number\n";
            goto B;
        }
        else
        {
            cout << "Valid Phone Number\n";
        }
    }
    string fname;
    fname = "\n" + cid + "\n" + firstname + "\n" + lastname + "\n" + reguser + "\n" + email + "\n" + date + "\n" + gender + "\n" + blood + "\n" + phone_no;
    int chhhose;
x:
    if (admin_choice == 1 || admin_choice == 3) {
        file.open("teacher.txt", ios::app);
        file << fname;
        cout << "\n\nYOUR DATA HAS BEEN SUCCESSFULLY INSERTED" << endl;
        cout << "\n\nPress Any Key To Continue..";
        file.close();
        shopping b;
    }
    else if (admin_choice == 2 || admin_choice == 4) {
        file.open("student.txt", ios::app);
        file << fname;
        cout << "\n\nYOUR DATA HAS BEEN SUCCESSFULLY INSERTED" << endl;
        cout << "\n\nPress Any Key To Continue..";
        file.close();
        shopping b;
    }
    else
        cout << choicelog;
}

void shopping::edit() {
    cout << "enter the id you wnt to update" << endl;
    string searchid;
    cin >> searchid;
    list<string> it;
    list<string> it2;
    ifstream a;
    if (admin_choice == 3) {
        a.open("teacher.txt");
    }
    else {
        a.open("student.txt");
    }
    if (!a.is_open()) {
        cout << "file canot be open";
    }
    else {
        while (!a.eof()) {
            a >> this->cid;
            it.push_back(this->cid);
            a >> this->firstname;
            it.push_back(this->firstname);
            a >> this->lastname;
            it.push_back(this->lastname);
            a >> this->username;
            it.push_back(this->username);
            a >> this->email;
            it.push_back(this->email);
            a >> this->date;
            it.push_back(this->date);
            a >> this->gender;
            it.push_back(this->gender);
            a >> this->blood;
            it.push_back(this->blood);
            a >> this->phone_no;
            it.push_back(this->phone_no);
            if (a.eof()) {
                break;
            }
        }
        string t;
        string l;
        a.close();
        bool mmm = true;
        if (admin_choice == 3) {
            a.open("teacher.txt");
        }
        else {
            a.open("student.txt");
        }        list<string>::iterator i;
        for (i = it.begin(); i != it.end(); ++i) {
            if (*i == searchid) {
                add();
                while (!a.eof()) {
                    if (mmm == true) {
                        a >> this->cid;
                    }
                    if (searchid != cid) {
                        mmm = true;
                        it2.push_back(this->cid);
                        t = this->cid;
                        a >> this->firstname;
                        it2.push_back(this->firstname);
                        a >> this->lastname;
                        it2.push_back(this->lastname);
                        a >> this->username;
                        it2.push_back(this->username);
                        a >> this->email;
                        it2.push_back(this->email);
                        a >> this->date;
                        it2.push_back(this->date);
                        a >> this->gender;
                        it2.push_back(this->gender);
                        a >> this->blood;
                        it2.push_back(this->blood);
                        a >> this->phone_no;
                        it2.push_back(this->phone_no);
                        if (a.eof()) {
                            break;
                        }
                    }
                    else {
                        mmm = false;
                        a >> l;
                        a >> l;
                        a >> l;
                        a >> l;
                        a >> l;
                        a >> l;
                        a >> l;
                        a >> l;
                        a >> cid;
                        if (a.eof()) {
                            break;
                        }
                    }
                }
                break;
            }
        }
        ofstream a22;
        if (admin_choice == 3) {
            a22.open("teacher.txt");
        }
        else {
            a22.open("student.txt");
        }
        int k = 0;
        for (i = it2.begin(); i != it2.end(); ++i) {
            k = k + 1;
        }
        int m = 0;
        for (i = it2.begin(); i != it2.end(); ++i) {
            if (*i == t) {
                *i = searchid;
            }
            cout << '\t' << *i;
            a22 << *i;
            cout << '\n';
            if (k - 1 != m) {
                a22 << '\n';
            }
            m = m + 1;
        }
    }
    administrator();
}
