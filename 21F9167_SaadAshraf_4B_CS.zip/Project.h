#pragma once
#include<iostream>
#include<fstream>
#include<conio.h>
#include<cstring>
#include<string>
#include<Windows.h>
using namespace std;

class variables {
protected:
    string n, lastname, firstname, username, email, password, date, gender, blood, phone_no;
    bool b = false;
    fstream data, data1;
    string cid;
    char token = '1';
    int pid;
    bool m = false;
};

class shopping : public variables {
private:
    char SAName[20];
    char SAPass[20];
    int ch, i = 0, gen_captcha = 0, Input_captcha = 0;
public:
    bool Admin_login();
    void menu();
    void administrator();
    void add();
    void edit();
};
