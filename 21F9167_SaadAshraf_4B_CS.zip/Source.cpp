#include<iostream>
#include<fstream>
#include<conio.h>
#include<cstring>
#include<string>
#include<Windows.h>
#include "Project.h"
using namespace std;

int main() {
    shopping a;
    a.menu();
}
